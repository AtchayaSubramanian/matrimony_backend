package com.atchaya.security.entity;

public enum Role {
    USER,
    ADMIN
}
