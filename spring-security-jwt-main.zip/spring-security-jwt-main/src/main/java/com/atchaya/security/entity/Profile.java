package com.atchaya.security.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Profile {
	 @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
    
     private String name;
     private int age;
     private String gender;
     private String location;
     private String occupation;
     private String religion;
     private String caste;
     private String mothertongue;
     private String Education;
     private String familydetails;
     private String Interest;
//     private String email;
//     private String height;
//     private String weight;
}
