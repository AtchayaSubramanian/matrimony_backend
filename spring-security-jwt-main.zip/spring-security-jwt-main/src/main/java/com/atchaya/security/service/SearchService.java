package com.atchaya.security.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.atchaya.security.entity.Search;
import com.atchaya.security.repository.SearchRepo;

import lombok.RequiredArgsConstructor;
@RequiredArgsConstructor
@Service
public class SearchService {
private final SearchRepo searchRepo;
public Optional<Search> getStudent(int id){
	return searchRepo.findById(id);
}

}
