package com.atchaya.security.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.atchaya.security.entity.Search;
import com.atchaya.security.repository.SearchRepo;
//import com.iamneo.security.service.AuthenticationService;
import com.atchaya.security.service.SearchService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class SearchController {
private final SearchRepo searchRepo;
private final SearchService searchServ;
@PostMapping("/post")
public Search create(@RequestBody Search prof) {
return searchRepo.save(prof);
}
@GetMapping("/getvalues")
List<Search> getList(){
return searchRepo.findAll();
}
@GetMapping("/getvalues/{id}")
public Optional<Search> getbyid(@PathVariable int id){
	return searchServ.getStudent(id);
}
}
